# DrugAlpha MCP 接入包 · v0.2

让你自己的 AI 查询 DrugAlpha 已发布投研数据。服务运行在线上，无需部署本地服务器，不消耗 DrugAlpha AI API。

- 服务地址：https://drugalpha.com/mcp
- 协议：Streamable HTTP；授权：OAuth + PKCE
- 账号：拥有 DrugAlpha 正式内容阅读权限的账号
- 当前范围：身份与催化剂、公司管线、公司估值、靶点/适应症竞争格局、指南、临床数据、资产概览、精选、已发布晨报、说明书、药价、公司点评资料、费用框架，以及板块估值/持仓结论与Excel。流行病学和指标解释暂缓，见文末。实际以当前账号授权和工具列表为准。
- 已验证：Codex 桌面内置 CLI 0.159.2，浏览器授权与真实查询（2026-10-04）
- 已验证：Codex 桌面 GitHub 插件目录添加、插件安装、集成工具加载及 IBI363 催化剂真实查询（2026-10-04，用户实测截图）。
- 已验证：WorkBuddy 5.5.6，浏览器授权、药物识别与催化剂真实查询（2026-10-04，用户实测确认）
- Claude Code CLI 2.1.289：已验证浏览器 OAuth 授权及连接（2026-10-04）；模型驱动的真实查询、桌面 Code 页面仍待验收。已验证范围不代表所有版本、系统和客户端均兼容。

## 让 AI 帮你配置

将本文件夹交给你的 Agent，发送：“请阅读 INSTALL-AGENT.md，按步骤帮我连接 DrugAlpha MCP。”

也可以直接把下面这段话交给 Agent：

> 请读取公共仓库 https://github.com/max-nobug/drugalpha-mcp 中的 README.md 和 INSTALL-AGENT.md，按照指引帮我配置 DrugAlpha MCP。保留已有客户端设置，由我在浏览器完成登录授权，最后验证真实查询是否成功。

## Codex 插件安装（GitHub 自建目录）

在支持插件目录的 Codex 版本中运行：

```sh
codex plugin marketplace add max-nobug/drugalpha-mcp
```

然后在插件界面或 `/plugins` 中找到 **DrugAlpha 创新药投研** 并安装。由你在浏览器完成 DrugAlpha 登录授权，再开启新会话查询。

这是 DrugAlpha 自建的 GitHub 插件目录，尚未上架 OpenAI 官方目录。已在 Codex 桌面完成添加目录、安装、集成工具加载和真实查询验证。已有手动连接时先核对，避免重复连接，不自动删除旧配置。不支持插件入口的客户端仍可用下方手动配置。

功能由主站服务及当前授权控制，旧连接可能需要重新授权新增范围。服务内容更新由线上服务提供；插件图标、skill 或安装配置更新后需刷新插件目录/插件，具体操作以当前客户端支持的命令或界面为准。

MCP Registry 元数据与维护说明见 [REGISTRY.md](REGISTRY.md)。登记不等于客户端内置市场收录。

## 下载手动接入包

- 公共仓库：https://github.com/max-nobug/drugalpha-mcp
- ZIP 下载：https://github.com/max-nobug/drugalpha-mcp/raw/refs/heads/main/downloads/drugalpha-mcp-v0.2.zip
- Git 拉取：`git clone https://github.com/max-nobug/drugalpha-mcp.git`

无需克隆投研平台代码或安装服务端。下载 ZIP 后解压，或直接让 Agent 阅读仓库中的安装指引即可。

## WorkBuddy 配置

服务端已开放标准 OAuth 动态注册，无需使用 Codex 的客户端身份或固定回调端口。WorkBuddy 5.5.6 已完成真实查询验证；以下为客户端手动配置示例。市场连接器包使用另一种配置格式，不要混用。

```json
{"mcpServers":{"drugalpha":{"type":"http","url":"https://drugalpha.com/mcp"}}}
```

请让 Agent 确认 WorkBuddy 实际生效的 MCP 配置位置，备份后只合并 drugalpha 项，保留其他连接。然后在 WorkBuddy 中发起连接，由用户自行完成浏览器登录授权。看到工具列表并真实执行公司识别、催化剂查询后，才能报告连接成功；如失败，反馈脱敏后的错误提示，不发送令牌或完整回调链接。

## Claude Code 配置（授权与连接已验证，问答待验收）

识别实际使用的 Claude Code 可执行文件，先备份用户配置、检查同名服务，保留其他设置。使用该版本 CLI 帮助确认参数后添加：

```sh
claude mcp add --transport http --scope user drugalpha https://drugalpha.com/mcp
```

这是用户级配置，跨项目可用；不要复用 Codex 的固定 client_id 或 8900 端口，不填写 API Key。授权使用服务端动态注册。

支持 `mcp login` 的版本可以运行 `claude mcp login drugalpha`；否则启动 Claude Code，在 `/mcp` 中选择 DrugAlpha 并按提示授权。用户自行在 DrugAlpha 浏览器页面登录及确认。随后用 `claude mcp get drugalpha` 核对连接，再开启会话查询“IBI363 后续有哪些催化剂？请注明时间精度和来源。”

仅配置保存或浏览器成功不足以证明真实查询成功；应确认两个工具可见并实际完成实体识别与催化剂查询。Claude Code CLI、VS Code 扩展和 Claude 桌面 Code 入口需按实际客户端分别检查，不假定它们共享全部配置。

## Codex 手动配置

1. 将 codex.toml 中的配置合并到 Codex 用户配置，通常是 ~/.codex/config.toml。不要覆盖现有文件；同名服务存在时先核对。
2. 使用支持预注册 OAuth 客户端的 Codex。运行 codex mcp add --help，确认存在 --oauth-client-id。旧版命令行可能不支持，桌面版内置 CLI 与系统 PATH 中版本也可能不同。
3. 使用同一个 Codex 可执行文件运行：codex mcp login drugalpha。
4. 在浏览器登录 DrugAlpha，点击“允许连接”。密码只在 DrugAlpha 网站输入，不发给 AI。
5. 浏览器跳至 http://127.0.0.1:8900/callback 是本机 Codex 接收授权结果，MCP 服务仍在线上。看到 Authentication complete 且命令行确认成功后，重新加载 MCP 或打开新的 Codex 会话。

8900 端口须空闲；发生占用不要任意修改回调地址，先关闭先前的授权窗口/进程或联系平台。远程开发机、容器和跨设备浏览器尚未验证。

## 试问

- 恒瑞医药未来 12 个月有哪些催化剂？请注明时间精度和数据来源。
- 查找某药物，再列出与它已确认关联的后续催化剂。

Agent 应先解析公司/药物，再使用本次返回的标识查询，不编造标识。结果按正式发布范围呈现；没有查询结果不等于没有相关事件。年度、季度等区间不可伪装成确定日期，研究预期不可写成事实。

## 管理连接

https://drugalpha.com/oauth/connections 可查看并撤销授权。退出网站不会撤销 Agent 授权。初期已开放模块不限业务额度，但 Agent 自身的模型费用由对应服务计算。

## 功能边界

完整DCF任务、海外药物销售、股票技术分析、平台AI生成及业务写入未开放。临床对比复用已有临床查询，由用户agent保留原研究口径分析；治疗费用提供框架与资料，由用户agent测算。

本包只包含公开配置和指引，不含密钥或服务端代码。各平台市场条目尚未发布，不影响已验证客户端通过此接入包连接。

如需反馈问题，请在公共仓库的 Issues 中描述客户端版本、操作步骤及脱敏后的错误提示。不要上传密码、令牌、Cookie、完整客户端配置或授权回调链接。

## 新增查询与授权

先查看当前会话实际工具和schema，不把旧客户端验证当成新增功能全部兼容。本人公司估值优先使用已保存模型；板块使用平台公共结果。分析、费用测算和点评由用户agent执行，不调用DrugAlpha AI API。完整DCF任务、海外销售、平台AI生成及业务写入不开放。旧连接只授权身份/催化剂时，可按客户端提示重新授权所需的管线、估值、知识或临床范围；由用户确认，不自动同意，不索取令牌。详见QUERY-GUIDE.md。

## 本次实际开放范围（2026-10-07）

主站当前开放16项查询和2项板块Excel。公司管线详情get_pipeline已开放。流行病学get_epidemiology及指标解释get_metric_definitions暂缓：它们的正式发布清单或指针需要由原模块同步；MCP不补写发布记录。其他查询以本次授权及实际工具列表为准。已有连接只看到旧工具时，按客户端入口重新授权所需范围，再开启新会话。

手动配置名为drugalpha的Codex服务，可先用codex mcp login --help确认支持--scopes，再运行：

```sh
codex mcp login drugalpha --scopes entity:read,catalysts:read,pipeline:read,valuation:read,knowledge:read,clinical:read
```

GitHub插件连接请使用插件自身的授权入口，不为此重复添加手动服务。用户在浏览器确认权限，不能自动同意或把令牌交给agent。旧版本客户端只证明之前的基础查询兼容，不证明新增模块问答已全部验收。
